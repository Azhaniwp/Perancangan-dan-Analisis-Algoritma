from collections import defaultdict

class Graph:
    def __init__(self, vertices):
        self.V = vertices
        self.graph = defaultdict(list)

    def tambah_sisi(self, u, v, bobot):
        self.graph[u].append((v, bobot))
        self.graph[v].append((u, bobot))

    def cari_min_bobot(self, key, mstSet):
        min_value = float('inf')
        min_index = -1

        for v in range(self.V):
            if key[v] < min_value and not mstSet[v]:
                min_value = key[v]
                min_index = v

        return min_index

    def prim(self):
        key = [float('inf')] * self.V
        parent = [-1] * self.V
        key[0] = 0
        mstSet = [False] * self.V

        for _ in range(self.V):
            u = self.cari_min_bobot(key, mstSet)
            mstSet[u] = True

            for v, bobot in self.graph[u]:
                if not mstSet[v] and bobot < key[v]:
                    parent[v] = u
                    key[v] = bobot

        return parent

    def print_mst(self, parent):
        print("Sisi   : Bobot")
        for i in range(1, len(parent)):
            if parent[i] != -1:
                print(f"{parent[i]} - {i}  : {self.graph[parent[i]][i]}")

g = Graph(5)
g.tambah_sisi(0, 1, 2)
g.tambah_sisi(0, 3, 6)
g.tambah_sisi(1, 2, 3)
g.tambah_sisi(1, 3, 8)
g.tambah_sisi(1, 4, 5)
g.tambah_sisi(2, 4, 7)
g.tambah_sisi(3, 4, 9)

parent = g.prim()
g.print_mst(parent)
